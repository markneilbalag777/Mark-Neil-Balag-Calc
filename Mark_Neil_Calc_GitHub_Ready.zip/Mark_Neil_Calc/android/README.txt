Mark Neil Calc — Android application

This is the Android WebView wrapper for the Mark Neil Calc construction calculator.
The calculator UI and calculation engine are in:
app/src/main/assets/index.html

Features:
- Construction calculator: addition, subtraction, multiplication, and division
- Shared 1/16 and 1/32 fraction precision
- Fractional input selectors that follow the selected precision
- Exact rational arithmetic internally
- Inches and feet measuring-tape output
- Inch, millimeter, centimeter, meter, and feet conversions
- Offline-capable bundled web assets

Build from the repository root with:
  gradle -p android assembleDebug

The GitHub Actions workflow in .github/workflows/android.yml builds the debug APK.
