MARK NEIL BALAG CALC — OFFLINE ANDROID PROJECT

The calculator UI and calculation code work offline after the files are available on the phone.

Included features:
- Independent unit selector for Input 1 and Input 2: inches, mm, cm, m, ft.
- Exact requested fraction picker order:
  1/16, 1/8, 3/16, 1/4, 5/16, 3/8, 7/16, 1/2, 9/16, 5/8, 11/16, 3/4, 13/16, 7/8, 15/16.
- Add, subtract, multiply, divide.
- Result selector: inches, mm, cm, m, ft.
- Full conversion list, unit converter, calculation history, copy result.
- Black and orange interface.
- No network calls required by the calculator.

PHONE-ONLY USE:
1. Download Mark_Neil_Balag_Calc_Offline.html.
2. Open it from Downloads using Chrome or an HTML Viewer.
3. It runs as an offline local calculator.

ANDROID APK:
The `android` folder is a complete Android Studio WebView project with the HTML bundled locally. It is not a compiled APK. Compiling a signed APK requires Android SDK/Gradle build tooling. This runtime has no Android SDK/Gradle, so an APK cannot be honestly provided from here. The phone-ready HTML file can be used immediately offline.
