# Mark Neil Balag Calc

Offline construction and unit calculator for Android.

## Included features

- Addition, subtraction, multiplication, and division using exact rational arithmetic.
- Calculator tape results rounded independently to the nearest 1/16 and 1/32.
- Conversion table for inches, millimeters, centimeters, meters, and feet; area calculations show squared units.
- Standalone Unit Converter with 1/16 and 1/32 precision selectors and a fraction dropdown beside the input.
- Inches output in the standalone converter follows the selected precision.
- Offline Android WebView app, app icons, manifest, and service worker.

## Android project

Open the `android` folder in Android Studio, or build it in CI with Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17, and Android SDK Platform 35.

The Android application ID is `com.markneil.balagcalc`. Version: 1.2 (versionCode 3).

## Calculation behavior

- Length addition and subtraction are converted to a common base unit before calculating.
- Multiplication of two lengths produces area; multiplication by a number produces length.
- Division by a number produces length; division of two lengths produces a ratio. For tape use, the ratio is also shown as a tape-style inch result and converted across the five requested units.
- Tape values are rounded using integer/rational arithmetic, not floating-point rounding.

## GitHub upload

This archive preserves the expected project path `Mark_Neil_Balag_Calc/android` for the existing repository workflow. Upload this archive to the repository root using the filename `Mark_Neil_Balag_Calc_Android_APK_Builder.zip`, replacing the previous ZIP. Keep the repository's existing `.github/workflows/build-apk.yml` file. After committing, open the latest run in the Actions tab and download the `Mark-Neil-Balag-Calc-APK` artifact.
