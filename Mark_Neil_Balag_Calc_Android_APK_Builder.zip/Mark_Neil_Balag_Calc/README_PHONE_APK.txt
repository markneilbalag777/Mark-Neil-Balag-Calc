MARK NEIL BALAG CALC — ANDROID APK BUILD

This project is configured to build an Android APK in GitHub Actions, so you do not need a computer or Android Studio.

PHONE-ONLY STEPS
1. Download and extract this ZIP on your Android phone.
2. Sign in to GitHub or create a free account at github.com.
3. In GitHub, create a new repository named mark-neil-balag-calc.
4. Upload the extracted project files and folders to the repository. Make sure the .github/workflows/build-apk.yml file is included. GitHub's website may hide dot-folders in some upload flows; if so, use the GitHub mobile app/browser desktop mode or upload the workflow file separately.
5. Open the repository's Actions tab.
6. Select "Build Mark Neil Balag Calc APK" and tap "Run workflow" if it has not started automatically.
7. Wait for the workflow to finish successfully.
8. Open the completed workflow run, scroll to Artifacts, and download "Mark-Neil-Balag-Calc-APK".
9. Extract the downloaded artifact ZIP and tap app-debug.apk to install it. Android may ask you to allow installs from that browser/files app.

APP DETAILS
- App name: Mark Neil Balag Calc
- Subtitle: Construction & Unit Calculation
- Has its own Android launcher icon.
- Works offline: calculator UI and logic are bundled inside the APK.
- No internet permission is requested by the app.
- Inputs support inches, mm, cm, m, ft independently.
- Fraction choices: 1/16, 1/8, 3/16, 1/4, 5/16, 3/8, 7/16, 1/2, 9/16, 5/8, 11/16, 3/4, 13/16, 7/8, 15/16.
- Operations: +, -, x, ÷.
- Result conversion, converter, history, copy result.

NOTE
The APK has not yet been built or signed in this chat. GitHub Actions performs the build and provides an installable debug APK artifact. A debug APK is suitable for personal installation; it is not a Play Store release.
