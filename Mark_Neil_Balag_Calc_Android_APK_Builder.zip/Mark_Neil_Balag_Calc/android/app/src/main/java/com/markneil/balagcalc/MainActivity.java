package com.markneil.balagcalc;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.view.ViewGroup;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  getWindow().setStatusBarColor(android.graphics.Color.rgb(9,9,9));
  getWindow().setNavigationBarColor(android.graphics.Color.rgb(9,9,9));
  WebView web = new WebView(this);
  web.setLayoutParams(new ViewGroup.LayoutParams(-1,-1));
  WebSettings settings = web.getSettings();
  settings.setJavaScriptEnabled(true);
  settings.setDomStorageEnabled(true);
  settings.setAllowFileAccess(true);
  web.loadUrl("file:///android_asset/index.html");
  setContentView(web);
 }
 @Override public void onBackPressed() { super.onBackPressed(); }
}
