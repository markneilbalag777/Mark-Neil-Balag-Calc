Mark Neil Balag Calc - Android project

Offline construction and unit calculator.

Features:
- Exact rational arithmetic for +, -, x, and division.
- Dual tape outputs rounded to 1/16 and 1/32.
- Conversion table: inches, mm, cm, m, and ft (area calculations use squared units).
- Standalone converter with 1/16 or 1/32 precision and a fraction dropdown.
- Inches output in the standalone converter follows the selected precision.

Build requirements: JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3, Android SDK Platform 35.
Application ID: com.markneil.balagcalc
Version: 1.2 (versionCode 3)
