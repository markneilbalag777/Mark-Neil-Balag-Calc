# Mark Neil Calc

**Construction & Unit Calculation** — a mobile-first construction calculator and unit converter with fractional measuring-tape precision.

## What's included

- `index.html` — GitHub Pages / browser version of the app.
- `manifest.webmanifest`, `sw.js`, and `icons/` — installable, offline-capable web app assets.
- `android/` — the existing Android WebView project, updated to use the same calculator interface and calculation engine.
- `.github/workflows/` — automated GitHub Pages deployment and Android debug APK build workflows.

## Calculator features

- Addition, subtraction, multiplication, and division.
- Shared fraction precision selector: **1/16** or **1/32** only.
- Fraction dropdowns update to match the selected precision.
- Exact rational arithmetic is used internally; the selected 1/16 or 1/32 tape reading is rounded first, then used consistently for the main result and every linear unit conversion.
- Output and conversion support for inches, millimeters, centimeters, meters, and feet.
- Feet display uses feet plus remaining inches (for example, `1 ft 2 1/8 in`); measurements below one foot show `0 ft` plus the remaining inches.
- Conversion table updates with the calculated result.
- Dark interface with orange active controls and green result text.

## Publish the web app with GitHub Pages

1. Upload the **contents of this folder** to the root of your GitHub repository.
2. Push the files to the `main` branch.
3. Open **Settings → Pages** in the repository.
4. Under **Build and deployment**, select **GitHub Actions** as the source.
5. The `Deploy GitHub Pages` workflow publishes the web app automatically.
6. Open the Pages URL shown in **Settings → Pages**.

The root `index.html` is the GitHub Pages entry point. The Android app uses the matching copy at `android/app/src/main/assets/index.html`.

## Build the Android APK

The `Build Android APK` workflow runs automatically on pushes and pull requests to `main`.

To build locally, install JDK 17 and Gradle 8.9, then run:

```bash
gradle -p android assembleDebug
```

The debug APK is generated at:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

On GitHub, download the `mark-neil-calc-debug-apk` artifact from the completed **Build Android APK** workflow run.

## Calculation and display behavior

All calculations are performed using exact rational values. The 1/16 or 1/32 setting controls the measuring-tape result. The app rounds the linear result to the selected tape precision first, then converts that rounded inch value to millimeters, centimeters, meters, and feet. This keeps every displayed unit consistent with the measuring-tape reading. Millimeter, centimeter, and meter values are displayed as decimals. Feet conversions include the remaining inches, including `0 ft` for results below one foot.

## Latest calculator behavior (v1.3.1)

- Linear measurement display follows the selected 1/16 or 1/32 tape precision.
- Multiplication treats Input 1 as a length and Input 2 as a quantity; the result is shown in inches (in), not square inches.
- Division results are shown in inches (in), with the result conversion table below.
- All linear conversion values are calculated from the rounded 1/16 or 1/32 tape result, not the hidden full-precision value.
- Feet conversion explicitly shows `0 ft` for measurements shorter than one foot.
