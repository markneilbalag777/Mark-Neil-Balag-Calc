Mark Neil Balag Calc - corrected Android project

This project includes exact rational arithmetic for length measurements.
Supported units: inches, millimeters, centimeters, meters, feet.
Operations: addition, subtraction, multiplication, division.

Build with the repository GitHub Actions workflow.
